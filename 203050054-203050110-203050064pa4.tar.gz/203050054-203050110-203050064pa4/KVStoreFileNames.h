#ifndef PA_4_KEY_VALUE_STORE_KVSTOREFILENAMES_H
#define PA_4_KEY_VALUE_STORE_KVSTOREFILENAMES_H

// REFER: https://stackoverflow.com/questions/1433204/how-do-i-use-extern-to-share-variables-between-source-files
// REFER: https://stackoverflow.com/questions/10422034/when-to-use-extern-in-c
extern char kvStoreFileNames[16384][6];

#endif // PA_4_KEY_VALUE_STORE_KVSTOREFILENAMES_H
